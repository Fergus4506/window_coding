﻿namespace ex13_airplan
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bullet_sample = new System.Windows.Forms.PictureBox();
            this.ept_sample = new System.Windows.Forms.PictureBox();
            this.plane = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bullet_sample)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ept_sample)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plane)).BeginInit();
            this.SuspendLayout();
            // 
            // bullet_sample
            // 
            this.bullet_sample.BackColor = System.Drawing.Color.Transparent;
            this.bullet_sample.Image = global::ex13_airplan.Properties.Resources.bullet1;
            this.bullet_sample.Location = new System.Drawing.Point(102, 12);
            this.bullet_sample.Name = "bullet_sample";
            this.bullet_sample.Size = new System.Drawing.Size(30, 73);
            this.bullet_sample.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bullet_sample.TabIndex = 2;
            this.bullet_sample.TabStop = false;
            this.bullet_sample.Visible = false;
            // 
            // ept_sample
            // 
            this.ept_sample.BackColor = System.Drawing.Color.Transparent;
            this.ept_sample.Image = global::ex13_airplan.Properties.Resources.enemy_removeBG;
            this.ept_sample.Location = new System.Drawing.Point(148, 45);
            this.ept_sample.Name = "ept_sample";
            this.ept_sample.Size = new System.Drawing.Size(90, 69);
            this.ept_sample.TabIndex = 1;
            this.ept_sample.TabStop = false;
            this.ept_sample.Visible = false;
            this.ept_sample.Click += new System.EventHandler(this.ept_sample_Click);
            // 
            // plane
            // 
            this.plane.BackColor = System.Drawing.Color.Transparent;
            this.plane.Image = global::ex13_airplan.Properties.Resources.plane_removeBG;
            this.plane.Location = new System.Drawing.Point(41, 113);
            this.plane.Name = "plane";
            this.plane.Size = new System.Drawing.Size(91, 78);
            this.plane.TabIndex = 0;
            this.plane.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "分數:0";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(207, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "剩餘時間:100";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(138, 131);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(148, 159);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "輸入遊玩時間";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::ex13_airplan.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bullet_sample);
            this.Controls.Add(this.ept_sample);
            this.Controls.Add(this.plane);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.bullet_sample)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ept_sample)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plane)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox plane;
        private System.Windows.Forms.PictureBox ept_sample;
        private System.Windows.Forms.PictureBox bullet_sample;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}

